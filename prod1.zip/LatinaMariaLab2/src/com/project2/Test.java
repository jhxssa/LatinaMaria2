package com.project2;


public class Test extends Object {

	public static void main(String[] args) {
		// setter and getter
		Camera c1 = new Camera(120, 16);
		c1.setBrand("Canon");
		System.out.println("Camera brand: " + c1.getBrand());
		c1.do1("record videos");
		
		DSLR d1 = new DSLR("Canon", 20000);
		d1.setBattery(9);
		d1.setPrice(120999.75);
		System.out.println("This camera costs " +  d1.getPrice() + " pesos"); 
		System.out.println("this camera's battery life can last up to " + d1.getBattery() + " hours");
		
		//method overloading
		d1.do2("wide angle",120);
		
		
		
	}
}