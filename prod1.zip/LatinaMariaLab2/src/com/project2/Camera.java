package com.project2;

public class Camera {

		//parent
	 protected String brand;
	int resolution;
	int memory;
	 
	// setter and getter
	 public void setBrand (String brand) {
			this.brand=brand;
		}
		public String getBrand() {
			return this.brand;
		}
		
		//constructor overloading
	public Camera (int resolution, int memory) {
	this.resolution=resolution;
	this.memory=memory;
	}
	
	//method overloading2
	void do1(String do2) {
		System.out.println("This camera can " + do2 );
	}
	
}