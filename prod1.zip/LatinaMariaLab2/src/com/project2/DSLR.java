package com.project2;

public class DSLR {
	//child
	String brand;
	 int battery;
	 private double price;
	 
	// setter and getter
	 public void setBattery (int battery) {
			this.battery=battery;
		}
	 public void setPrice(double price) {
			this.price=price;
		}
	 
	 public int getBattery() {
			return this.battery;
		}
	 public double getPrice() {
			return this.price;
		}
	 
	 //method overloading
	void do2 (String lens, int resolution) {
		System.out.println("this camera has " + lens + " lens and has " + resolution + " megapixels" );
	}
	public DSLR (String brand, int price) {
		super();
	
	}
}